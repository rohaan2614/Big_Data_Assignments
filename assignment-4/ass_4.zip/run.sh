# task 1
# psql -d csci_620_ass_2 -a -f scripts/1_export_from_psql.sql
# python3 /Users/rohaan/Desktop/Projects/RIT/CSCI_601_Intro_To_Big_Data/Big-Data-Assignments/assignment-4/programs/1_connect_db.py
# mongoimport --db csci_620_ass_4 --collection Movies --file /Users/rohaan/Desktop/Projects/RIT/CSCI_601_Intro_To_Big_Data/Big-Data-Assignments/assignment-4/movies.json --jsonArray
# mongoimport --db csci_620_ass_4 --collection Members --file /Users/rohaan/Desktop/Projects/RIT/CSCI_601_Intro_To_Big_Data/Big-Data-Assignments/assignment-4/members.json --jsonArray 

# task 2