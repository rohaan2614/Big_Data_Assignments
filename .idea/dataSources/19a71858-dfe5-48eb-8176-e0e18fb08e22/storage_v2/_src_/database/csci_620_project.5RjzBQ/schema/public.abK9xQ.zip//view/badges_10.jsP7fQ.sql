create view badges_10(_id, badges) as
SELECT u.id                AS _id,
       array_agg(bu.badge) AS badges
FROM users u
         JOIN badge_user bu ON bu.member = u.id
GROUP BY u.id
ORDER BY u.id
LIMIT 10;

alter table badges_10
    owner to rohaan;

