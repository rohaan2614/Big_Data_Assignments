create view comments_10(_id, comments) as
SELECT u.id                   AS _id,
       array_agg(ucp.comment) AS comments
FROM users u
         JOIN user_comments_posts ucp ON u.id = ucp.member
GROUP BY u.id
ORDER BY u.id
LIMIT 10;

alter table comments_10
    owner to rohaan;

