create view posts_10(_id, posts) as
SELECT u.id                           AS _id,
       array_agg(pu.post_history_row) AS posts
FROM users u
         JOIN post_history_user pu ON pu.member = u.id
GROUP BY u.id
ORDER BY u.id
LIMIT 10;

alter table posts_10
    owner to rohaan;

